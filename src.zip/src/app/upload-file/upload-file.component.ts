import { Component, OnInit } from '@angular/core';
// import { FormBuilder,FormGroup } from '@angular/forms';
import { CommonApiSrvService } from '../common/common-api-srv.service';
import { HttpEventType } from '@angular/common/http';
@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.css']
})
export class UploadFileComponent implements OnInit {
  
  // uploadForm:FormGroup;
  constructor(private uploadSrv:CommonApiSrvService) { }

  fileTypeCheck:boolean = false;
  fileName:string='';
  selectedFile:File=null;
  eventObj:any={};
  email:string;

  ngOnInit() {
    this.email=localStorage.getItem('user');
    console.log('email ',this.email)
  }

 
  onSelectedFile(event, fileName){
    this.eventObj=event;
    this.selectedFile =<File>event.target.files[0];
    console.log('event>>>>>',event);
    // console.log('file>>>>>',fileName);
    let fileExtension = fileName.split('.').pop();
    // console.log('fileExtension>>>>>',fileExtension);
   if(fileExtension === "json"){ 
    this.fileTypeCheck=false;
   }else{
    this.fileTypeCheck=true;

   }

    }

    upload(){
      const fd = new FormData();
      fd.append('json',this.selectedFile,this.selectedFile.name)
     this.uploadSrv.uploadFile(fd,{
       reportProgress:true,
       observe: 'events'
     }).subscribe(res =>{
       if(this.eventObj.type === HttpEventType.UploadProgress){
         console.log('upload progress   >>> ' +Math.round(this.eventObj.loaded / this.eventObj.total) *100 + '%')

       }else if(this.eventObj.type === HttpEventType.Response){
        console.log('uploaded file>>>>', res);

       }
     });
  
    }  
cancel(){
  this.fileName='';
  this.fileTypeCheck=false;
}


  }
