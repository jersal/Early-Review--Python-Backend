import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthInterceptor}   from './auth.interceptor';
import { from } from 'rxjs';
// import { LocalStorage } from '@ngx-pwa/local-storage';
// import { Observable } from 'rxjs';
// import { fromPromise } from 'rxjs/observable/fromPromise';
// import 'rxjs/add/operator/catch';
// import 'rxjs/add/operator/do';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/mergeMap';
// import 'rxjs/add/observable/throw';
// import 'rxjs/add/operator/toArray';


@Injectable({
  providedIn: 'root'
})
export class CommonApiSrvService {
  //baseUrl: string ="http://192.168.10.23:8000/";
  //for authentication:
// baseUrl:string="https://reqres.in/"
 
  constructor(private http: HttpClient) { }
  /****************for login************ */
  tokensave(data) {
    localStorage.setItem('token', data);
  }
  
  userSave(data){
    localStorage.setItem('user',data);
  }
  
  login(data) {
    // return this.http.post(this.baseUrl + 'api/registration/login/', data)
    return this.http.post<any>( '/api/login', data)
  }
  /****************for login************ */
  /****************file Uplod************ */
  uploadFile(file, obj){
    return this.http.post<any>('api/registration/upload/',file) 

  }
  /****************file Uplod************ */

  registration(data) {
    return this.http.post<any>( 'api/registration/register/', data);
}

}

