import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
/*imported from dev-section */
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule,routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { ToastrModule } from 'ngx-toastr';
import { UploadFileComponent } from './upload-file/upload-file.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AuthInterceptor } from './common/auth.interceptor';
@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    UploadFileComponent,
    NavbarComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ToastrModule.forRoot({
      timeOut: 5000,     
    positionClass: 'toast-top-right',
    preventDuplicates: true,
    })
    
  ],
  providers: [
    { provide:HTTP_INTERCEPTORS,
    useClass:AuthInterceptor,
    multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
